declare module 'js-md5'
