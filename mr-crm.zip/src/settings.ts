import type { Settings } from '#/global'

const globalSettings: Settings.all = {}

export default globalSettings
