// 文件目录信息
interface userNoticeItem {
  title: string
  csr_name: string
  next_follow_time: string
}
