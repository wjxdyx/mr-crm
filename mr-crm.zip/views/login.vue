<script lang="ts" setup name="Login">
import type { FormInstance, FormRules } from 'element-plus'
import useUserStore from '@/store/modules/user'
import apiUser from '@/api/modules/user'

const route = useRoute()
const router = useRouter()

const userStore = useUserStore()

const banner = new URL('../assets/images/login-banner.png', import.meta.url).href
const title = import.meta.env.VITE_APP_TITLE

// 表单类型，login 登录，reset 重置密码
const formType = ref('login')
const loading = ref(false)
const redirect = ref(route.query.redirect?.toString() ?? '/')

// 登录
const loginFormRef = ref<FormInstance>()
const loginForm = ref({
  account: localStorage.login_account || '',
  password: '',
  remember: !!localStorage.login_account,
})
const loginRules = ref<FormRules>({
  account: [
    { required: true, trigger: 'blur', message: '请输入用户名' },
  ],
  password: [
    { required: true, trigger: 'blur', message: '请输入密码' },
    { min: 6, max: 18, trigger: 'blur', message: '密码长度为6到18位' },
  ],
})
const eletest = ref('')
function handleChange(e, e2) {
  console.log(e, e2)
}
function handleLogin() {
  apiUser.login({ username: 111, password: 222 })
  loginFormRef.value && loginFormRef.value.validate((valid) => {
    if (valid) {
      loading.value = true
      userStore.login(loginForm.value).then(() => {
        loading.value = false
        if (loginForm.value.remember) {
          localStorage.setItem('login_account', loginForm.value.account)
        }
        else {
          localStorage.removeItem('login_account')
        }
        router.push(redirect.value)
      }).catch(() => {
        loading.value = false
      })
    }
  })
}
</script>

<template>
  <div>
    <div class="htmleaf-container">
      <div class="login">
        <div class="container">
          <h1>输入密码登录系统</h1>
          <form ref="loginFormRef">
            <input type="password" name="password">
            <input type="submit" value="登陆" @click="handleLogin">
            <el-input v-model="eletest" @change="e => handleChange(e, eletest)" />
          </form>
        </div>
      </div>
    </div>
    <Copyright />
  </div>
</template>
