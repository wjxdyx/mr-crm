<script lang="ts" setup name="Csr">
import { ArrowLeft, ArrowRight, Box, Folder, FolderAdd, Refresh, Search } from '@element-plus/icons-vue'
import apiDoc from '@/api/modules/doc'

const docSearch = ref('')

const docFile = ref<docFileLink[]>([
  {
    name: '',
  },
])
const docFileActive = ref<docFileActive>({})
async function querySearchAsync(queryString: string, cb: (arg: any) => void) {
  const res = (await apiDoc.docSearch(queryString))
  cb(res.data)
}

function handleSelect(item: Record<string, any>) {
  docSearch.value = item.name
}

function handleIconClick(item: string) {

}
function clickActive(item: docFileLink) {
  if (typeof item.name === 'string') {
    docFileActive.value = {}
    docFileActive.value[item.name] = item
  }
}
function handleFileNameChange(name: string, item: docFileLink) {
  if (typeof name === 'string') {
    apiDoc.docFileRename({ old: item.oldName, new: name }).then((r) => {
      console.log('success')
      item.oldName = name
    })
  }
}
const host = import.meta.env.VITE_APP_API_BASEURL
onMounted(() => {
  // 获取文件目录信息
  apiDoc.docFilePath().then((r) => {
    docFile.value = r.data
    docFile.value.forEach((ele) => {
      ele.oldName = JSON.stringify(JSON.parse(ele.name))
    })
  })
})
</script>

<template>
  <div class="layout-grid">
    <div class="header">
      <el-button-group>
        <el-button type="primary" round :icon="FolderAdd" color="#afafaf">
          New Folder
        </el-button>
        <el-button type="primary" round :icon="Box" color="#afafaf">
          New Product
        </el-button>
      </el-button-group>
      <el-autocomplete
        v-model="docSearch"
        :fetch-suggestions="querySearchAsync"
        :trigger-on-focus="false"
        clearable
        round
        class="inline-input w-50 search"
        placeholder=""
        @select="handleSelect"
      >
        <template #suffix>
          <el-icon class="el-input__icon" @click="handleIconClick">
            <Search />
          </el-icon>
        </template>
      </el-autocomplete>
    </div>
    <!-- 面包屑 -->
    <div class="bread">
      <el-icon class="el-icon" size="18px">
        <ArrowLeft />
      </el-icon>
      <el-icon class="el-icon" size="18px">
        <ArrowRight />
      </el-icon>
      <el-icon class="el-icon" size="18px">
        <Refresh />
      </el-icon>
      <div>
        <el-breadcrumb
          :separator-icon="ArrowRight" style="padding-left: 10px;border-left: 1px solid #afabab;"
        >
          <el-breadcrumb-item>path1</el-breadcrumb-item>
          <el-breadcrumb-item>path2</el-breadcrumb-item>
          <el-breadcrumb-item>path3</el-breadcrumb-item>
        </el-breadcrumb>
      </div>
    </div>

    <!-- 面板内容区 -->
    <div class="file-panel">
      <div
        v-for="item, index in docFile" :key="index"
        :class="{ active: docFileActive[item.name] }" class="doc-file" @click="clickActive(item)"
      >
        <div class="doc-file-image">
          <!-- <el-image v-if="['jpg', 'jpeg', 'png'].includes(item.typ ? item.typ : '')" :src="item.imgUrl ? item.imgUrl : '#'" /> -->
          <el-image v-if="['jpg', 'jpeg', 'png'].includes(item.name ? item.name : '')" :src="`${host}/resources/index/download?path=${item.name}`" />
          <el-image v-else>
            <template #error>
              <div class="image-slot">
                <el-icon size="84px">
                  <Folder />
                </el-icon>
              </div>
            </template>
          </el-image>
        </div>
        <div class="footer">
          <el-input v-model="item.name" style="height: 100%;" @change="e => handleFileNameChange(e, item)" />
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="scss" scoped>
.layout-grid {
  padding: 15px;
}
/* stylelint-disable-next-line scss/double-slash-comment-whitespace-inside */
//------文件预览-----//
.file-panel {
  padding: 10px 0;
  display: flex;
  gap: 15px;
  justify-items: center;
  align-items: center;
}

:deep(.doc-file) {
  .doc-file-image {
    height: 100%;
  }

  .el-image {
    padding: 0 5px;
    width: 100%;
    height: 100%;
  }

  .image-slot {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 100%;
    background-color: white;
    color: var(--el-text-color-secondary);
    font-size: 30px;

    .el-icon {
      font-size: 30px;
    }
  }

  border-radius: 10px;
  width: 200px;
  height: 240px;
  display: flex;
  flex-direction: column;
  overflow: hidden;

  .el-input__wrapper {
    padding: 0;
    box-shadow: unset;
    background-color: unset;
  }

  .el-input__inner {
    color: white;
    text-align: center;
  }

  .footer {
    height: 40px;
    margin-top: auto;
    background-color: #686868;
    color: white;
  }
}

.doc-file.active {
  border: 1px solid red;

  .image-slot {
    background-color: #f0f0f0;
  }
}
/* stylelint-disable-next-line scss/double-slash-comment-whitespace-inside */
//------面包屑-----//
.bread {
  padding: 8px;
  padding-left: 0;
  display: flex;
  align-items: center;
  border: 1px;
  border-style: solid;
  border-color: #c9c3c3;
  border-left: 0;
  border-right: 0;

  .el-icon {
    margin-right: 10px;
  }
}
/* stylelint-disable-next-line scss/double-slash-comment-whitespace-inside */
//------搜索产品-----//
:deep(.search) {
  margin-left: auto;
  padding-left: 10px;
  width: 400px;

  .el-input__wrapper {
    border-radius: 100px;
  }

  .el-input__suffix {
    border-left: 1px solid #eee;
  }
}

:deep(.header) {
  display: flex;
  padding-bottom: 10px;

  .el-button > span,
  .el-button svg {
    color: white;
  }
}
</style>
