<script lang="ts" setup name="Csr">
import { CirclePlus, Delete, UploadFilled } from '@element-plus/icons-vue'
import type { UploadFile, UploadFiles, UploadInstance, UploadRawFile } from 'element-plus'
import CsrTimeLine from './components/csrTimeline.vue'
import apiCsr from '@/api/modules/csr'

// 页面信息
const pageInfo = ref<pageType>({
  doc_from: {
    option: [
      { doc_from_id: 1, name: '电话' },
      { doc_from_id: 2, name: '淘宝' },
      { doc_from_id: 3, name: '微信' },
    ],
  },
})

// 页面信息
const saveForm = ref<csrSave>({
  from: '电话',
  name: '',
  code: '',
  phone: '',
  mark: '',
  state: 0,
  amt: undefined,
  proTable: [{}],
  // 合同附件图片
  contract: [],
  trackProveList: [{}],

  // 聊天图片弹窗
  trackProveVisible: false,
  // 聊天图片预览
  msg_log: [],
})
function handleCommand(state: number) {
  saveForm.value.state = state
}

const activeName = ref('first')
const csrActivities = ref<csrTimeLine[]>([])

async function csrTrack() {
  if (saveForm.value.crm_csr_id) {
    const { data } = (await apiCsr.csrTrack(saveForm.value.crm_csr_id))

    csrActivities.value = data
  }
}
// 搜索客户下拉

function querySearchAsync(fieldName: string, queryString: string, cb: (arg: any) => void) {
  apiCsr.csrSearch({ [fieldName]: queryString }).then((r) => {
    cb(r.data)
  })
}

function handleSelect(item: Record<string, any>) {
  saveForm.value.code = item.code
  saveForm.value.phone = item.phone
  saveForm.value.name = item.name

  saveForm.value.crm_csr_id = item.crm_csr_id
  csrTrack()
}
// 产品表
function addProRow() {
  saveForm.value.proTable.push({})
}
function delProRow(e: number) {
  saveForm.value.proTable.splice(e, 1)
}
// 删除文件
function handleRemove(file, fileList) {
  // this.fileList = fileList
  // this.addFileList = fileList.map(item => {
  //   return item.raw
  // })
}
// 删除文件确认
function beforeRemove() {
  return true
  // return this.$confirm(`确定取消上传:  ${file.name}`)
}
const formData = new FormData()
// 确认上传
function uploadSave(e) {
  const arrKey = Object.keys(saveForm.value)
  arrKey.forEach((ele: string) => {
    formData.append(ele, saveForm.value[ele])
  })
  apiCsr.saveDeal(formData)
  // return this.$confirm(`确定取消上传:  ${file.name}`)
}

const fileForm = ref<UploadRawFile[]>([])
// 文件上传操作
function fileChange(file: UploadFile, fileList: UploadFiles) {
  console.log(fileForm)

  if (file.raw) {
    // fileForm.value.push(file.raw)
    // formData.append('msg_log', file.raw)
    // formData.append('filename', 'msg_log')
    //
    // formData.append('aaa', 'xxx')

    // console.log(fileForm.value, fileList)
  }
  //
}
const uploadRef = ref<UploadInstance>()
function submitUpload() {
  // uploadRef.value!.submit()
}
onMounted(() => {

})
</script>

<template>
  <div class="layout-grid">
    <page-main class="filter-header" style="height: 100%;">
      <template #title>
        <span>保存成交客户 </span>
        <el-button type="primary">
          保存
        </el-button>
      </template>
      <el-tabs v-model="activeName" class="demo-tabs">
        <el-tab-pane label="销售线索" name="first" style="height: 100%;">
          <div style="display: flex;flex-direction: row;height: 100%;">
            <div style="padding-bottom: 20px;">
              <el-form :inline="false" class="csr-form" label-width="80px" label-position="left">
                <el-form-item label="客户名称">
                  <el-autocomplete v-model="saveForm.name" value-key="name"
                    :fetch-suggestions="(e: string, cb) => querySearchAsync('name', e, cb)" placeholder="客户名"
                    @select="handleSelect">
                    <template #default="{ item }">
                      <span class="value">
                        {{ item.name }}[{{ item.code }}]
                      </span>
                      <span class="item-phone">{{ item.phone }}</span>
                    </template>
                  </el-autocomplete>
                </el-form-item>

                <el-form-item label="手机号码">
                  <el-input v-model="saveForm.phone" placeholder="Please input" />
                </el-form-item>
                <el-form-item label="业务类型">
                  <el-select v-model="saveForm.from" class="" style="width: 100%;" placeholder="业务类型">
                    <el-option v-for="item, index in pageInfo?.doc_from.option" :key="index" :label="item.name"
                      :value="item.name" />
                  </el-select>
                </el-form-item>
                <!-- <el-form-item label="收货地址" style="grid-column-start: span 2;">
                  <el-input v-model="saveForm.address" placeholder="Please input" />
                </el-form-item> -->
                <el-form-item label="备注说明" style="grid-column-start: span 3;">
                  <el-input v-model="saveForm.mark" placeholder="请按客户实际询盘明细录入！" type="textarea" />
                </el-form-item>
                <el-form-item label="聊天记录" style="grid-column-start: span 3;height: 140px;">
                  <!-- <el-upload
                    v-model:file-list="saveForm.trackProveList"
                    :auto-upload="false"
                    action="http://mr-crm.erpgj.com/public/index.php/resources/index/up" list-type="picture-card"
                  >
                    <el-icon />
                  </el-upload>

                  <el-dialog v-model="saveForm.trackProveVisible">
                    <img w-full :src="saveForm.msg_log" alt="Preview Image">
                  </el-dialog> -->
                  <!-- <el-upload
                    ref="uploadRef"
                    class="upload-demo"
                    name="msg_log"
                    :data="{ filename: 'msg_log' }"
                    action="http://mr-crm.erpgj.com/public/index.php/resources/index/up"
                    :auto-upload="false"
                  >
                    <template #trigger>
                      <el-button type="primary">
                        select file
                      </el-button>
                    </template>

                    <el-button class="ml-3" type="success" @click="submitUpload">
                      upload to server
                    </el-button>

                    <template #tip>
                      <div class="el-upload__tip">
                        jpg/png files with a size less than 500kb
                      </div>
                    </template>
                  </el-upload> -->
                  <el-upload class="upload" action="" multiple :auto-upload="false" :on-remove="handleRemove"
                    :before-remove="beforeRemove" :file-list="fileForm" :on-change="fileChange">
                    <el-button type="primary">
                      选择文件
                    </el-button>
                  </el-upload>
                  <el-button @click="uploadSave">
                    上传
                  </el-button>
                </el-form-item>
                <el-form-item label="产品" style="grid-column-start: span 3;height: 100%;">
                  <div>
                    <el-table :data="saveForm.proTable" border style="width: 100%;">
                      <el-table-column prop="pro_name" label="产品名称" width="140">
                        <template #default="scope">
                          <div style="display: flex; align-items: center;justify-content: flex-start;">
                            <el-button type="primary" :icon="CirclePlus" link style="position: relative;left: -5px;"
                              @click="addProRow" />
                            <el-input v-model="scope.row.pro_name" placeholder="Please input" />
                            <el-button type="danger" :icon="Delete" link style="position: relative;left: 5px;"
                              @click="delProRow(scope.$index)" />
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column prop="tpy" label="型号" width="100">
                        <template #default="scope">
                          <div style="display: flex; align-items: center;">
                            <el-input v-model="scope.row.tpy" placeholder="Please input" />
                          </div>
                        </template>
                      </el-table-column>

                      <el-table-column prop="quantity" label="数量" width="80">
                        <template #default="scope">
                          <div style="display: flex; align-items: center;">
                            <el-input v-model="scope.row.quantity" placeholder="Please input" />
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column prop="amount" label="单价" width="80">
                        <template #default="scope">
                          <div style="display: flex; align-items: center;">
                            <el-input v-model="scope.row.amount" placeholder="Please input" />
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column prop="mark" label="备注">
                        <template #default="scope">
                          <div style="display: flex; align-items: center;">
                            <el-input v-model="scope.row.mark" placeholder="Please input" />
                          </div>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </el-form-item>
              </el-form>
            </div>
            <!-- 客户跟踪 -->
            <div style="width: 400px;margin-left: auto;max-height: 400px;overflow: auto;">
              <div style="height: 100%;">
                <CsrTimeLine :track-data="csrActivities" />
              </div>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="合同附件" name="second">
          <el-upload class="upload-demo" drag action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
            multiple>
            <el-icon class="el-icon--upload">
              <UploadFilled />
            </el-icon>
            <div class="el-upload__text">
              拖拽文件到此处<em>点击上传</em>
            </div>
            <template #tip>
              <div class="el-upload__tip">
                jpg/png 格式
              </div>
            </template>
          </el-upload>
        </el-tab-pane>
      </el-tabs>
    </page-main>
  </div>
</template>

<style lang="scss" scoped>
:deep(.el-tabs__content) {
  flex: 1;
}

:deep(.el-tabs) {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.layout-grid {
  height: 100%;
  padding: 20px;
}

// ------------自动补全下拉框----------//
.item-phone {
  color: #999;
  font-size: 12px;
}

// ------------header tool----------//
.filter-header {
  height: 100%;
  display: flex;
  flex-direction: column;

  :deep(.title-container) {
    display: flex;
    justify-content: space-between;
    width: calc(100% + 40px);
    align-items: center;
    padding: 7px 20px;
    border-bottom: 1px solid var(--el-border-color-lighter);
    transition: var(--el-transition-border);
  }

  .title-container {
    :deep(.el-input__wrapper, .el-input__wrapper:hover) {
      box-shadow: unset !important;
      border-bottom: 1px solid;
      border-radius: 0;

      input,
      .el-input__suffix {
        padding-top: 3px;
      }
    }

    :deep(.el-input.is-focus) {
      .el-input__wrapper {
        box-shadow: unset !important;
      }
    }
  }
}

// ------------table----------//
:deep(.el-table__body) {
  .el-table__cell {
    padding: 0 !important;
  }

  .el-input__wrapper {
    padding: 0;
    box-shadow: unset;
    background-color: unset;
  }
}

.td.el-table__cel .csr-form {
  display: grid;
  align-items: center;
  padding-top: 30px;
  grid-template-columns: 1fr 1fr;
  grid-column-gap: 10px;
}

.csr-form {
  margin-top: 10px;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  grid-column-gap: 10px;
}

:deep(.el-form-item__content) {
  height: 40px;
}

.csr-form>div+.csr-form>div {
  margin-right: 10px;
}
</style>
