
interface docFromType {
  name: string
  doc_from_id: number
}
interface csrQueryFormType {
  from?: string
  name?: string
  phone?: string
  create_time?: any
  index?: number
  limit?: number
}
interface csrData {
  csr_name?: string
  phone?: string
  create_time?: any

  crm_csr_id?: number
}
interface pageInfoType {
  doc_from: {
    option: docFromType[]
  }
  queryForm: csrQueryFormType
  csrView: {
    drawer: boolean
    rowData: csrData
  }
}
interface pageType {
  doc_from: {
    option: docFromType[]
  }
  queryForm?: csrQueryFormType

}
interface proTable {
  pro_name?: string
  pro_id?: number
  amount?: number
  tpy?: string
  mark?: string
}
interface csrSave {
  name: string

  mark: string
  csr_id?: number | undefined
  from: string
  code: string
  state?: number
  crm_csr_id?: number
  amt?: number | undefined
  phone: string
  address?: string | undefined
  proTable: proTable[]
  contract: string[]
  trackProveList: UploadUserFile[]
  trackProveVisible: boolean
  trackProveUrl?: string
  msg_log?: any[]
}

// 客户跟踪事件记录
interface csrTimeLine {
  create_time?: string
  order_id?: number
  order_no?: string
  mark?: string
  order_pro?: string
  contract?: string[]
  track_prove?: string[]
}
