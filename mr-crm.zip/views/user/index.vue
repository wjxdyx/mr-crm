<script lang="ts" setup name="User">
import apiUser from '@/api/modules/user'

const search = ref({
  name: '',
  phone: '',
})
const staffTableData = ref([])
const page = ref({
  index: 1,
  limit: 30,
  total: 0,
})
async function clickQuerySearch() {
  const { data: { tableData: staffData, tableDataTotal: total } } = await (await apiUser.userAuthData(page.value.index, page.value.limit, search.value.name, search.value.phone))
  staffTableData.value = staffData
  page.value.total = total
}
function pageChange(e: number) {
  page.value.index = e
  clickQuerySearch()
}
onMounted(() => {
  clickQuerySearch()
})
</script>

<template>
  <div class="layout-grid">
    <page-main class="filter-header" title="员工信息">
      <el-form :inline="true" class="query-tobar">
        <el-form-item label="名称">
          <el-input v-model="search.name" placeholder="Please input" />
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="search.phone" placeholder="Please input" />
        </el-form-item>
        <el-form-item>
          <el-button type="danger" @click="clickQuerySearch">
            查询
          </el-button>
        </el-form-item>
      </el-form>
    </page-main>
    <!-- 面板内容区 -->
    <div style="padding: 0 20px;">
      <el-table
        border
        scrollbar-always-on stripe highlight-current-row
        :data="staffTableData" table-layout="auto"
        class="table-header-filter"
      >
        <el-table-column fixed type="index" label="序" width="50" />
        <el-table-column fixed prop="username" label="登陆账户" width="160">
          <template #default="scope">
            <el-link type="primary" :underline="false">
              {{ scope.row.username }}
            </el-link>
          </template>
        </el-table-column>

        <el-table-column fixed prop="nickname" label="昵称" width="100">
          <template #default="scope">
            <el-icon size="22px">
              <svg-icon v-if="scope.row.gender === 1" name="ep:female" class="translate-center" />
              <svg-icon v-if="scope.row.gender === 2" name="ep:male" class="translate-center" />
              <svg-icon v-if="scope.row.gender === 0" name="ep:user-filled" class="translate-center" />
            </el-icon>
            <el-link type="primary" :underline="false">
              {{ scope.row.nickname }}
            </el-link>
          </template>
        </el-table-column>
        <el-table-column label="登录IP" width="120">
          <template #default="scope">
            <el-link type="primary" :underline="false">
              {{ scope.row.ip }}
            </el-link>
          </template>
        </el-table-column>

        <el-table-column prop="reception" label="接待数" width="160" />
        <el-table-column prop="create_time" label="上次登录时间" width="160" />

        <el-table-column fixed prop="deviceUid" label="设备指纹" width="120" />

        <el-table-column prop="create_time" label="创建时间" width="180" />
        <el-table-column prop="create_time" label="更新时间" width="180" />
      </el-table>
      <el-pagination small background layout="prev, pager, next" :total="page?.total" style="margin-top: 10px;" @current-change="pageChange" />
    </div>
  </div>
</template>

<style lang="scss" scoped>
:deep(.table-header-filter) {
  .translate-center {
    margin-right: 8px;
    font-size: 18px;
  }

  tbody .cell {
    display: flex;
    align-content: center;
    align-items: center;
  }
}

/* stylelint-disable-next-line scss/double-slash-comment-whitespace-inside */
//------抽屉样式-----//
:deep(.el-tabs__content) {
  padding: 5px;
}

:deep(.el-tabs--border-card) {
  border: 0 !important;

  .el-tabs__header,
  .el-tabs__item {
    border: 0 !important;
  }
}

:deep(.csr-drawer) {
  top: unset;
  height: calc(100% - var(--g-header-height));

  .el-drawer__body {
    padding: 0 !important;
  }

  .el-drawer__header {
    background-color: #414141;
    padding: 0;
  }

  .el-drawer__title {
    background-color: #414141;
    padding: 10px;
  }

  .el-drawer__close-btn {
    position: absolute;
    right: 0;
    top: 10px;
  }

  .drawer-csr-panel {
    border-top: 1px solid #eee;
    display: grid;
    grid-template-columns: 1fr 1fr;
    font-size: 14px;
    justify-items: start;
    align-items: center;
    padding: 10px;
  }
}

:deep(.el-drawer__header) {
  background-color: #414141;
  color: white;
  margin: 0;
  padding: 10px;
}

.query-tobar {
  display: flex;
  align-items: center;
  padding-top: 30px;
}

.query-tobar > div + .query-tobar > div {
  margin-right: 10px;
}

.layout-grid {
  display: flex;
  flex-direction: column;
  height: 100%;
}

:deep(tbody) {
  .cell {
    padding: 0 10px;
  }
}
/* stylelint-disable-next-line scss/double-slash-comment-whitespace-inside */
//-----------//
.filter-header {
  :deep(.title-container) {
    display: flex;
    justify-content: space-between;
    width: calc(100% + 40px);
    padding: 14px 20px;
    margin-left: -20px;
    margin-top: -20px;
    margin-bottom: 0;
    border-bottom: 1px solid var(--el-border-color-lighter);
    transition: var(--el-transition-border);
  }
}

:deep(thead) {
  .el-table__cell {
    background-color: #efefef;
    font-size: 14px;
  }
}

:deep(.csr-table) {
  .el-table__cell:first-child {
    border-top-left-radius: 10px;
  }

  .el-table__cell:last-child {
    border-top-right-radius: 10px;
  }
}

.filter-table {
  margin-top: 0;
  padding: 5px;
}
</style>
